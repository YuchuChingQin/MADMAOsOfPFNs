% nameInput = {'HH1.txt', 'HH2.txt', 'HH3.txt', 'HH4.txt', 'HH5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2)); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2));
% end
% legend(nameLegend, 'Location', 'northeast')
% 
% 
% nameInput = {'FF1.txt', 'FF2.txt', 'FF3.txt', 'FF4.txt', 'FF5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2)); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2));
% end
% legend(nameLegend, 'Location', 'northeast')
%%%

% nameInput = {'WA1.txt', 'WA2.txt', 'WA3.txt', 'WA4.txt', 'WA5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend)
% 
% nameInput = {'WG1.txt', 'WG2.txt', 'WG3.txt', 'WG4.txt', 'WG5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend)

% nameInput = {'WBM1.txt', 'WBM2.txt', 'WBM3.txt', 'WBM4.txt', 'WBM5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend)
% 
% nameInput = {'WGBM1.txt', 'WGBM2.txt', 'WGBM3.txt', 'WGBM4.txt', 'WGBM5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend)
% 
% nameInput = {'WHM1.txt', 'WHM2.txt', 'WHM3.txt', 'WHM4.txt', 'WHM5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend)
% 
% nameInput = {'WGHM1.txt', 'WGHM2.txt', 'WGHM3.txt', 'WGHM4.txt', 'WGHM5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend)
% 
% nameInput = {'WMSM1.txt', 'WMSM2.txt', 'WMSM3.txt', 'WMSM4.txt', 'WMSM5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend)
% 
% nameInput = {'WGMSM1.txt', 'WGMSM2.txt', 'WGMSM3.txt', 'WGMSM4.txt', 'WGMSM5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend)
% 
% nameInput = {'H1.txt', 'H2.txt', 'H3.txt', 'H4.txt', 'H5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend, 'Location', 'southeast')
% 
% nameInput = {'F1.txt', 'F2.txt', 'F3.txt', 'F4.txt', 'F5.txt'};
% nameLegend = {'A1', 'A2', 'A3', 'A4', 'A5'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o'); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
% legend(nameLegend, 'Location', 'southeast')


nameInput = {'LD1.txt', 'LD2.txt', 'LD3.txt', 'LD4.txt', 'LD5.txt'};
nameLegend = {'E1', 'E2', 'E3', 'E4', 'E5'};

n = length(nameInput);
data = cell(n);

for i =1:n
    data{i} = load(nameInput{i});
end

figure
plot(data{1}(:,1), data{1}(:,2), '-'); hold on; grid on;
for i =2:n
    plot(data{i}(:,1), data{i}(:,2), '-');
end
legend(nameLegend, 'Location', 'northeast')


nameInput = {'EP1.txt', 'EP2.txt', 'EP3.txt', 'EP4.txt', 'EP5.txt'};
nameLegend = {'E1', 'E2', 'E3', 'E4', 'E5'};

n = length(nameInput);
data = cell(n);

for i =1:n
    data{i} = load(nameInput{i});
end

figure
plot(data{1}(:,1), data{1}(:,2), '-'); hold on; grid on;
for i =2:n
    plot(data{i}(:,1), data{i}(:,2), '-');
end
legend(nameLegend, 'Location', 'northeast')
