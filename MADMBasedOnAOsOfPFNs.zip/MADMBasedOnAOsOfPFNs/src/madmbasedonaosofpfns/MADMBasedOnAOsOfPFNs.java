/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package madmbasedonaosofpfns;

/**
 * @developers Yuchu Qin & Peizhi Shi
 * @emails: qinyuchu@hud.ac.uk & peizhi.shi@manchester.ac.uk 
 **/
import java.util.ArrayList;  
import java.util.List; 
import java.util.stream.*;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class MADMBasedOnAOsOfPFNs {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here          
        MADMBasedOnAOsOfPFNs madm = new MADMBasedOnAOsOfPFNs();
        int mmm = 5;
        int nnn = 4;              
        double[] www = {0.2, 0.1, 0.3, 0.4};//Example 1,2
        //double[] www = {0.2, 0.3, 0.1, 0.4};//Example 3
        
        //Example 1
        double[][][] MMM = {
            {{0.56, 0.34, 0.10}, {0.90, 0.07, 0.03}, {0.40, 0.33, 0.19}, {0.09, 0.79, 0.03}},       
            {{0.70, 0.10, 0.09}, {0.10, 0.66, 0.20}, {0.06, 0.81, 0.12}, {0.72, 0.14, 0.09}},
            {{0.88, 0.09, 0.03}, {0.08, 0.10, 0.06}, {0.05, 0.83, 0.09}, {0.65, 0.25, 0.07}},
            {{0.80, 0.07, 0.04}, {0.70, 0.15, 0.11}, {0.03, 0.88, 0.05}, {0.07, 0.82, 0.05}},
            {{0.85, 0.06, 0.03}, {0.64, 0.07, 0.22}, {0.06, 0.88, 0.05}, {0.13, 0.77, 0.09}}
        };
        
        /*//Example 2
        double[][][] MMM = {
            {{0.53,0.33,0.09}, {0.89,0.08,0.03}, {0.42,0.35,0.18}, {0.08,0.89,0.02}},
            {{0.73,0.12,0.08}, {0.13,0.64,0.21}, {0.03,0.82,0.13}, {0.73,0.15,0.08}},
            {{0.91,0.03,0.02}, {0.07,0.09,0.05}, {0.04,0.85,0.10}, {0.68,0.26,0.06}},
            {{0.85,0.09,0.05}, {0.74,0.16,0.10}, {0.02,0.89,0.05}, {0.08,0.84,0.06}},
            {{0.90,0.05,0.02}, {0.68,0.08,0.21}, {0.05,0.87,0.06}, {0.13,0.75,0.09}}
        };
        
        //Example 3 
        double[][][] MMM = {
            {{0.2, 0.1, 0.6}, {0.1, 0.3, 0.5}, {0.3, 0.1, 0.5}, {0.4, 0.3, 0.2}},
            {{0.1, 0.4, 0.4}, {0.1, 0.3, 0.6}, {0.2, 0.2, 0.5}, {0.2, 0.1, 0.7}},
            {{0.3, 0.2, 0.2}, {0.1, 0.2, 0.6}, {0.3, 0.1, 0.4}, {0.3, 0.3, 0.4}},
            {{0.3, 0.1, 0.6}, {0.6, 0.2, 0.1}, {0.5, 0.3, 0.1}, {0.2, 0.3, 0.2}}
        };*/
        
        double[] SUPP1221 = new double[mmm];
        double[] SUPP1331 = new double[mmm];
        double[] SUPP1441 = new double[mmm];
        double[] SUPP2332 = new double[mmm];
        double[] SUPP2442 = new double[mmm];
        double[] SUPP3443 = new double[mmm];
        for (int i = 0; i < mmm; i++) {          
            SUPP1221[i] = 1 - distanceValue(MMM[i][0][0], MMM[i][0][1], MMM[i][0][2], MMM[i][1][0], MMM[i][1][1], MMM[i][1][2]);
            SUPP1331[i] = 1 - distanceValue(MMM[i][0][0], MMM[i][0][1], MMM[i][0][2], MMM[i][2][0], MMM[i][2][1], MMM[i][2][2]);
            SUPP1441[i] = 1 - distanceValue(MMM[i][0][0], MMM[i][0][1], MMM[i][0][2], MMM[i][3][0], MMM[i][3][1], MMM[i][3][2]);                 
            SUPP2332[i] = 1 - distanceValue(MMM[i][1][0], MMM[i][1][1], MMM[i][1][2], MMM[i][2][0], MMM[i][2][1], MMM[i][2][2]);
            SUPP2442[i] = 1 - distanceValue(MMM[i][1][0], MMM[i][1][1], MMM[i][1][2], MMM[i][3][0], MMM[i][3][1], MMM[i][3][2]);       
            SUPP3443[i] = 1 - distanceValue(MMM[i][2][0], MMM[i][2][1], MMM[i][2][2], MMM[i][3][0], MMM[i][3][1], MMM[i][3][2]);                 
        }
        double[] TTT1 = new double[mmm];
        double[] TTT2 = new double[mmm]; 
        double[] TTT3 = new double[mmm]; 
        double[] TTT4 = new double[mmm]; 
        for (int i = 0; i < mmm; i++) {          
            TTT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i]; 
            TTT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i];
            TTT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i];
            TTT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i];                  
        }
        double[] WWW1 = new double[mmm];
        double[] WWW2 = new double[mmm];
        double[] WWW3 = new double[mmm];
        double[] WWW4 = new double[mmm];       
             
        for (int i = 0; i < mmm; i++) {     
            WWW1[i] = (www[0]*(1.0 + TTT1[i])) / (www[0]*(1.0 + TTT1[i]) + www[1]*(1.0 + TTT2[i]) + www[2]*(1.0 + TTT3[i]) + www[3]*(1.0 + TTT4[i]));
            WWW2[i] = (www[1]*(1.0 + TTT2[i])) / (www[0]*(1.0 + TTT1[i]) + www[1]*(1.0 + TTT2[i]) + www[2]*(1.0 + TTT3[i]) + www[3]*(1.0 + TTT4[i]));
            WWW3[i] = (www[2]*(1.0 + TTT3[i])) / (www[0]*(1.0 + TTT1[i]) + www[1]*(1.0 + TTT2[i]) + www[2]*(1.0 + TTT3[i]) + www[3]*(1.0 + TTT4[i]));
            WWW4[i] = (www[3]*(1.0 + TTT4[i])) / (www[0]*(1.0 + TTT1[i]) + www[1]*(1.0 + TTT2[i]) + www[2]*(1.0 + TTT3[i]) + www[3]*(1.0 + TTT4[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(WWW4[i]));
        }
           
        double[][] WCB = {
            {WWW1[0], WWW2[0], WWW3[0], WWW4[0]},
            {WWW1[1], WWW2[1], WWW3[1], WWW4[1]},
            {WWW1[2], WWW2[2], WWW3[2], WWW4[2]},
            {WWW1[3], WWW2[3], WWW3[3], WWW4[3]},
            {WWW1[4], WWW2[4], WWW3[4], WWW4[4]}          
        };
        double[][] rrr = new double[mmm][3];
        for (int k = 0; k < mmm; k++) {
            for (int t = 0; t < 3; t++) {
                rrr[k][t] = 0.0;
            }           
        }
        
        double[] delta = {1.0, 1.0, 1.0, 0.0};
        //rrr = madm.PFWA(mmm, nnn, MMM, www);//[36]
        //rrr = madm.PFHWA(3.0, mmm, nnn, MMM, www);//[37,38]
        //rrr = madm.PFDWA(3.0, mmm, nnn, MMM, www);//[39]
        //rrr = madm.PFWHM(mmm, nnn, MMM, www, 1.0, 2.0);//[40]
        //rrr = madm.PFDWHM(3.0, mmm, nnn, MMM, www, 1.0, 2.0);//[41]      
        //rrr = madm.PFWMM(mmm, nnn, 1.0, MMM, www, delta);//[42]
        //rrr = madm.PFAAPWMSM(mmm, nnn, 1.0, MMM, WCB, 4);
        //rrr = madm.PFAEPWMSM(mmm, nnn, 1.0, MMM, WCB, 4);
        rrr = madm.PFAHPWMSM(1.0, mmm, nnn, 1.0, MMM, WCB, 3);
        //rrr = madm.PFAFPWMSM(3.0, mmm, nnn, 1.0, MMM, WCB, 3);
                          
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.print("PFN[" + index + "] = ");
            System.out.print("<" + new java.text.DecimalFormat("#0.0000").format(rrr[k][0]) + ", ");
            System.out.print(new java.text.DecimalFormat("#0.0000").format(rrr[k][1]) + ", ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rrr[k][2]) + ">");
        }  
        
        double[] scoreValue = new double[mmm];                 
        scoreValue = madm.getScoreValue(mmm, rrr);
        System.out.println("SV:");
        for (int k = 0; k < mmm; k++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(scoreValue[k]));
        }
               
        /*int nX = 1000;              
        double[] rangeX = {1.01, 20.00};          
        double stepX = ( rangeX[1] - rangeX[0] ) / ( nX - 1);         
        double[] x = new double [nX];       
        double[] score = new double [nX];
        double[] SV = new double[mmm];         
        File fileWrite = new File("Output.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));
        
        for (int i = 0; i < nX; ++i) {           
                x[i] = rangeX[0] + i * stepX;              
                writer.write(String.valueOf(x[i]) + " ");
                SV = madm.getScoreValue(mmm, madm.PFAFPWMSM(x[i], mmm, nnn, 1.0, MMM, WCB, 3));                                 
                score[i] = SV[4];               
                writer.write(String.valueOf(score[i]) + "\r\n");           
        }             
        writer.close();*/
                         
        double[] accuracyValue = new double[mmm];                 
        accuracyValue = madm.getAccuracyValue(mmm, rrr);
        System.out.println("AV:");
        for (int k = 0; k < mmm; k++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(accuracyValue[k]));
        }
        ArrayIndexComparator comparator = new ArrayIndexComparator(scoreValue, accuracyValue);
	Integer[] indexes = comparator.createIndexArray();
	Arrays.sort(indexes, comparator);
        System.out.println("Ranking:");
	for(int i = 0; i < indexes.length; i++) {           
            int index = indexes[i]+1;
            System.out.print("E[" + index + "] > ");
        }
    }
    
    public double[][] PFAAPWMSM(int m, int n, double q, double[][][] theta, double[][] w, int kk) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0; i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);   
        double[] delta = new double[n];
        for (int j = 0; j < kk; j++) {
            delta[j] = 1.0;
        }
        for (int jj = kk; jj < n; jj++) {
            delta[jj] = 0.0;
        }
        double[][] result = new double[m][3];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;
            result[k][2] = 1.0;
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                double product2 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][0], q), n*w[k][curidx]), delta[j]);
                    product1 *= Math.pow((1.0 - Math.pow(theta[k][curidx][1], q*n*w[k][curidx])), delta[j]);
                    product2 *= Math.pow((1.0 - Math.pow(theta[k][curidx][2], q*n*w[k][curidx])), delta[j]);
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
                result[k][2] *= (1.0 - product2);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1), 1.0/q);
            result[k][2] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][2], factorial1(n)), sumdelta1), 1.0/q);
        }        
        return result;             
    }              
    
    public double[][] PFAEPWMSM(int m, int n, double q, double[][][] theta, double[][] w, int kk) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0; i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp); 
        double[] delta = new double[n];
        for (int j = 0; j < kk; j++) {
            delta[j] = 1.0;
        }
        for (int jj = kk; jj < n; jj++) {
            delta[jj] = 0.0;
        }
        double[][] product = new double[m][3];
        double[][] result = new double[m][3];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0; 
            product[k][2] = 1.0;
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                double product2 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(
                               (Math.pow(1.0+Math.pow(theta[k][curidx][0], q), n*w[k][curidx]) + 3.0*Math.pow(1.0-Math.pow(theta[k][curidx][0], q), n*w[k][curidx])) /
                               (Math.pow(1.0+Math.pow(theta[k][curidx][0], q), n*w[k][curidx]) - Math.pow(1.0-Math.pow(theta[k][curidx][0], q), n*w[k][curidx])),                                                     
                                delta[j]);                                                                             
                    product1 *= Math.pow(                                                 
                               (Math.pow(2.0 - Math.pow(theta[k][curidx][1], q), n*w[k][curidx]) + 3.0*Math.pow(theta[k][curidx][1], q*n*w[k][curidx])) /
                               (Math.pow(2.0 - Math.pow(theta[k][curidx][1], q), n*w[k][curidx]) - Math.pow(theta[k][curidx][1], q*n*w[k][curidx])),                                                                                                                                   
                                delta[j]);
                    product2 *= Math.pow(                                                 
                               (Math.pow(2.0 - Math.pow(theta[k][curidx][2], q), n*w[k][curidx]) + 3.0*Math.pow(theta[k][curidx][2], q*n*w[k][curidx])) /
                               (Math.pow(2.0 - Math.pow(theta[k][curidx][2], q), n*w[k][curidx]) - Math.pow(theta[k][curidx][2], q*n*w[k][curidx])),                                                                                                                                   
                                delta[j]);
                }                              
                product[k][0] *= ((product0 + 3.0) / (product0 - 1.0));
                product[k][1] *= ((product1 + 3.0) / (product1 - 1.0));
                product[k][2] *= ((product2 + 3.0) / (product2 - 1.0));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow((2 * Math.pow(Math.pow(product[k][0], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][0], factorial1(n)) + 3.0, sumdelta1) + 
                           Math.pow(Math.pow(product[k][0], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);                                                         
            result[k][1] = Math.pow((Math.pow(Math.pow(product[k][1], factorial1(n)) + 3.0, sumdelta1) - 
                           Math.pow(Math.pow(product[k][1], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][1], factorial1(n)) + 3.0, sumdelta1) + 
                           Math.pow(Math.pow(product[k][1], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);
            result[k][2] = Math.pow((Math.pow(Math.pow(product[k][2], factorial1(n)) + 3.0, sumdelta1) - 
                           Math.pow(Math.pow(product[k][2], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][2], factorial1(n)) + 3.0, sumdelta1) + 
                           Math.pow(Math.pow(product[k][2], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);
        }        
        return result;       
    } 
    
    public double[][] PFAHPWMSM(double lambda, int m, int n, double q, double[][][] theta, double[][] w, int kk) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0; i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp); 
        double[] delta = new double[n];
        for (int j = 0; j < kk; j++) {
            delta[j] = 1.0;
        }
        for (int jj = kk; jj < n; jj++) {
            delta[jj] = 0.0;
        }
        double[][] product = new double[m][3];
        double[][] result = new double[m][3];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0; 
            product[k][2] = 1.0;
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                double product2 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow((Math.pow(lambda+(1.0-lambda)*(1.0-Math.pow(theta[k][curidx][0], q)), n*w[k][curidx]) +
                                         (lambda*lambda-1.0)*Math.pow(1.0-Math.pow(theta[k][curidx][0], q), n*w[k][curidx])) /
                                         (Math.pow(lambda+(1.0-lambda)*(1.0-Math.pow(theta[k][curidx][0], q)), n*w[k][curidx]) -
                                          Math.pow(1.0-Math.pow(theta[k][curidx][0], q), n*w[k][curidx])), delta[j]);             
                    product1 *= Math.pow((Math.pow(lambda+(1.0-lambda)*Math.pow(theta[k][curidx][1], q), n*w[k][curidx]) +
                                         (lambda*lambda-1.0)*Math.pow(theta[k][curidx][1], q*n*w[k][curidx])) /
                                         (Math.pow(lambda+(1.0-lambda)*Math.pow(theta[k][curidx][1], q), n*w[k][curidx]) -
                                          Math.pow(theta[k][curidx][1], q*n*w[k][curidx])), delta[j]);
                    product2 *= Math.pow((Math.pow(lambda+(1.0-lambda)*Math.pow(theta[k][curidx][2], q), n*w[k][curidx]) +
                                         (lambda*lambda-1.0)*Math.pow(theta[k][curidx][2], q*n*w[k][curidx])) /
                                         (Math.pow(lambda+(1.0-lambda)*Math.pow(theta[k][curidx][2], q), n*w[k][curidx]) -
                                          Math.pow(theta[k][curidx][2], q*n*w[k][curidx])), delta[j]);
                }                              
                product[k][0] *= ((product0 + lambda*lambda - 1.0) / (product0 - 1.0));
                product[k][1] *= ((product1 + lambda*lambda - 1.0) / (product1 - 1.0));
                product[k][2] *= ((product2 + lambda*lambda - 1.0) / (product2 - 1.0));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow((lambda * Math.pow(Math.pow(product[k][0], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][0], factorial1(n)) + lambda*lambda - 1.0, sumdelta1) + 
                           (lambda-1)*Math.pow(Math.pow(product[k][0], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);                                                         
            result[k][1] = Math.pow((Math.pow(Math.pow(product[k][1], factorial1(n)) + lambda*lambda - 1.0, sumdelta1) - 
                           Math.pow(Math.pow(product[k][1], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][1], factorial1(n)) + lambda*lambda - 1.0, sumdelta1) + 
                           (lambda-1)*Math.pow(Math.pow(product[k][1], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);
            result[k][2] = Math.pow((Math.pow(Math.pow(product[k][2], factorial1(n)) + lambda*lambda - 1.0, sumdelta1) - 
                           Math.pow(Math.pow(product[k][2], factorial1(n)) - 1.0, sumdelta1)) / 
                          (Math.pow(Math.pow(product[k][2], factorial1(n)) + lambda*lambda - 1.0, sumdelta1) + 
                           (lambda-1)*Math.pow(Math.pow(product[k][2], factorial1(n)) - 1.0, sumdelta1)), 1.0/q);
        }        
        return result;       
    } 
    
    public double[][] PFAFPWMSM(double epsilon, int m, int n, double q, double[][][] theta, double[][] w, int kk) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0; i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);  
        double[] delta = new double[n];
        for (int j = 0; j < kk; j++) {
            delta[j] = 1.0;
        }
        for (int jj = kk; jj < n; jj++) {
            delta[jj] = 0.0;
        }  
        MADMBasedOnAOsOfPFNs tempLog = new MADMBasedOnAOsOfPFNs();
        double[][] product = new double[m][3];
        double[][] result = new double[m][3];
        for (int k = 0; k < m; k++) {            
            product[k][0] = 1.0;
            product[k][1] = 1.0; 
            product[k][2] = 1.0;
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                double product2 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow((epsilon - 1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, 1.0 + 
                               (Math.pow(Math.pow(epsilon, 1.0 - Math.pow(theta[k][curidx][0], q)) - 1.0, n*w[k][curidx])) / 
                               (Math.pow(epsilon-1.0, n*w[k][curidx]-1.0)))) - 1.0), delta[j]);                                                                                          
                    product1 *= Math.pow((epsilon-1.0) / (Math.pow(epsilon, 1.0 - 
                                tempLog.logAnyBase(epsilon, 1.0 + (Math.pow(Math.pow(epsilon, Math.pow(theta[k][curidx][1], q)) - 1.0, n*w[k][curidx])) /
                               (Math.pow(epsilon-1.0, n*w[k][curidx]-1.0)))) - 1.0), delta[j]);
                    product2 *= Math.pow((epsilon-1.0) / (Math.pow(epsilon, 1.0 - 
                                tempLog.logAnyBase(epsilon, 1.0 + (Math.pow(Math.pow(epsilon, Math.pow(theta[k][curidx][2], q)) - 1.0, n*w[k][curidx])) /
                               (Math.pow(epsilon-1.0, n*w[k][curidx]-1.0)))) - 1.0), delta[j]);
                }                              
                product[k][0] *= ((epsilon-1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product0)/(product0)))-1.0));
                product[k][1] *= ((epsilon-1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product1)/(product1)))-1.0));
                product[k][2] *= ((epsilon-1.0) / (Math.pow(epsilon, 1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+product2)/(product2)))-1.0));
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(tempLog.logAnyBase(epsilon, 1.0 + ((epsilon-1.0)*Math.pow(Math.pow(epsilon, 
                           1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+Math.pow(product[k][0], factorial1(n)))/
                          (Math.pow(product[k][0], factorial1(n)))))-1.0, sumdelta1)) / (Math.pow(epsilon-1.0, sumdelta1))), 1.0/q);                                                         
            result[k][1] = Math.pow(1.0 - tempLog.logAnyBase(epsilon, 1.0 + ((epsilon-1.0)*Math.pow(Math.pow(epsilon, 
                           1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+Math.pow(product[k][1], factorial1(n)))/
                          (Math.pow(product[k][1], factorial1(n)))))-1.0, sumdelta1)) / (Math.pow(epsilon-1.0, sumdelta1))), 1.0/q);  
            result[k][2] = Math.pow(1.0 - tempLog.logAnyBase(epsilon, 1.0 + ((epsilon-1.0)*Math.pow(Math.pow(epsilon, 
                           1.0 - tempLog.logAnyBase(epsilon, (epsilon-1.0+Math.pow(product[k][2], factorial1(n)))/
                          (Math.pow(product[k][2], factorial1(n)))))-1.0, sumdelta1)) / (Math.pow(epsilon-1.0, sumdelta1))), 1.0/q);  
        }        
        return result;       
    }
    
    public static void permutation(ArrayList<Integer> s, ArrayList<Integer> rs, ArrayList<ArrayList<Integer>> res) {                     
        if(s.size()== 1) {               
            rs.add(s.get(0));  
            ArrayList<Integer> tmp=new ArrayList<Integer>();  
            for(Integer a:rs)  
                tmp.add(a);
            res.add(tmp);
            rs.remove(rs.size()-1);                              
        } else {                 
            for(int i=0;i<s.size();i++) {                    
                rs.add(s.get(i));   
                ArrayList<Integer> tmp=new ArrayList<Integer>();  
                for(Integer a:s)  
                     tmp.add(a);  
                tmp.remove(i);  
                permutation(tmp,rs,res);  
                rs.remove(rs.size()-1);                
            }  
        }                     
    }
    
    public static double factorial1(int number) {
        double result = 1;
        for (int factor = 2; factor <= number; factor++) {
            result *= factor;
        }
        return 1.0/result;
    }
    
    public static double distanceValue(double mu1, double eta1, double nu1, double mu2, double eta2, double nu2) {
        double distanceValue = 0.0;
        distanceValue = 0.5 * (Math.abs(mu1-mu2) + Math.abs(eta1-eta2) + Math.abs(nu1-nu2));
        return distanceValue;
    }
    
    public double[] getScoreValue(int m, double[][] theta) {
        double[] scoreValue = new double[m];
        for (int k = 0; k < m; k++) {
            scoreValue[k] = 0.5 * (1.0 + theta[k][0] - theta[k][2]);
            //scoreValue[k] = theta[k][0] - theta[k][2];
        }
        return scoreValue;
    }
    
    public double[] getAccuracyValue(int m, double[][] theta) {
        double[] accuracyValue = new double[m];
        for (int k = 0; k < m; k++) {
            accuracyValue[k] = theta[k][0] + theta[k][1] + theta[k][2];
        }
        return accuracyValue;
    }
    
    public double logAnyBase(double base, double value) {
        return Math.log(value)/Math.log(base);
    }
    
    //Wei et al. 2017 [36] 
    public double[][] PFWA(int m, int n, double[][][] theta, double[] w) {
        double[][] resultOfPFWA = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 3; r++) {
                resultOfPFWA[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 3; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                                  
                product[k][0] = product[k][0] * Math.pow(1-theta[k][i][0], w[i]);
                product[k][1] = product[k][1] * Math.pow(theta[k][i][1], w[i]);
                product[k][2] = product[k][2] * Math.pow(theta[k][i][2], w[i]); 
            }
            resultOfPFWA[k][0] = 1 - product[k][0];
            resultOfPFWA[k][1] = product[k][1];
            resultOfPFWA[k][2] = product[k][2];
        }
        return resultOfPFWA;
    }
    
    //Garg [37] and Wei [38]
    public double[][] PFHWA(double lambda, int m, int n, double[][][] theta, double[] w) {
        double[][] resultOfPFHWA = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int t = 0; t < 3; t++) {
                resultOfPFHWA[k][t] = 0.0;
            }           
        }        
        double[][] productA = new double[m][3];
        double[][] productB = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int t = 0; t < 3; t++) {
                productA[k][t] = 1.0;
                productB[k][t] = 1.0;
            }           
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                                 
                productA[k][0] = productA[k][0] * Math.pow(1.0 + (lambda-1.0)*theta[k][i][0], w[i]);
                productB[k][0] = productB[k][0] * Math.pow(1.0 - theta[k][i][0], w[i]);
                
                productA[k][1] = productA[k][1] * Math.pow(1.0 + (lambda-1.0)*(1.0-theta[k][i][1]), w[i]);
                productB[k][1] = productB[k][1] * Math.pow(theta[k][i][1], w[i]);
                
                productA[k][2] = productA[k][2] * Math.pow(1.0 + (lambda-1.0)*(1.0-theta[k][i][2]), w[i]);
                productB[k][2] = productB[k][2] * Math.pow(theta[k][i][2], w[i]);
            }
            resultOfPFHWA[k][0] = (productA[k][0] - productB[k][0]) / (productA[k][0] + (lambda-1.0)*productB[k][0]);
            resultOfPFHWA[k][1] = (lambda*productB[k][1]) / (productA[k][1]+(lambda-1.0)*productB[k][1]);
            resultOfPFHWA[k][2] = (lambda*productB[k][2]) / (productA[k][2]+(lambda-1.0)*productB[k][2]);
        }        
        return resultOfPFHWA;
    }
    
    //Jana et al. 2019 [39]
    public double[][] PFDWA(double r, int m, int n, double[][][] theta, double[] w) {
        double[][] resultOfPFDWA = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int t = 0; t < 3; t++) {
                resultOfPFDWA[k][t] = 0.0;
            }           
        }        
        double[][] sum = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int t = 0; t < 3; t++) {
                sum[k][t] = 0.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                                 
                sum[k][0] = sum[k][0] + w[i]*Math.pow((theta[k][i][0]/(1.0-theta[k][i][0])), r);
                sum[k][1] = sum[k][1] + w[i]*Math.pow(((1.0-theta[k][i][1])/theta[k][i][1]), r);
                sum[k][2] = sum[k][2] + w[i]*Math.pow(((1.0-theta[k][i][2])/theta[k][i][2]), r);
            }
            resultOfPFDWA[k][0] = 1.0 - 1.0/(1+Math.pow(sum[k][0], 1.0/r));
            resultOfPFDWA[k][1] = 1.0 / (1.0+Math.pow(sum[k][1], 1.0/r));
            resultOfPFDWA[k][2] = 1.0 / (1.0+Math.pow(sum[k][2], 1.0/r));
        }       
        return resultOfPFDWA;
    }
    
    //Wei et al. [40]
    public double[][] PFWHM(int m, int n, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfPFWHM = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 3; r++) {
                resultOfPFWHM[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 3; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = i; j < n; j++) {                   
                    product[k][0] = product[k][0] * Math.pow(1 - Math.pow(theta[k][i][0], a*w[i]) 
                                                  * Math.pow(theta[k][j][0], b*w[j]), 2.0/(n*n+n));
                    product[k][1] = product[k][1] * Math.pow(1 - Math.pow(1 - theta[k][i][1], a*w[i]) 
                                                  * Math.pow(1 - theta[k][j][1], b*w[j]), 2.0/(n*n+n));
                    product[k][2] = product[k][2] * Math.pow(1 - Math.pow(1 - theta[k][i][2], a*w[i]) 
                                                  * Math.pow(1 - theta[k][j][2], b*w[j]), 2.0/(n*n+n));
                }
            }
            resultOfPFWHM[k][0] = Math.pow(1 - product[k][0], 1.0/(a+b));
            resultOfPFWHM[k][1] = 1 - Math.pow(1 - product[k][1], 1.0/(a+b));
            resultOfPFWHM[k][2] = 1 - Math.pow(1 - product[k][2], 1.0/(a+b));
        }
        return resultOfPFWHM;
    }
    
    //Zhang et al. [41]
    public double[][] PFDWHM(double lambda, int m, int n, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfPFDWHM = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 3; r++) {
                resultOfPFDWHM[k][r] = 0.0;
            }           
        }   
        double[][] sum = new double[m][3];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 3; r++) {
                sum[k][r] = 0.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = i; j < n; j++) {                   
                    sum[k][0] = sum[k][0] + 1.0/(a/(w[i]*Math.pow(theta[k][i][0]/(1.0-theta[k][i][0]), lambda)) + 
                                                 b/(w[j]*Math.pow(theta[k][j][0]/(1.0-theta[k][j][0]), lambda)));                          
                    sum[k][1] = sum[k][1] + 1.0/(a/(w[i]*Math.pow((1.0-theta[k][i][1])/theta[k][i][1], lambda)) + 
                                                 b/(w[j]*Math.pow((1.0-theta[k][j][1])/theta[k][j][1], lambda)));  
                    sum[k][2] = sum[k][2] + 1.0/(a/(w[i]*Math.pow((1.0-theta[k][i][2])/theta[k][i][2], lambda)) + 
                                                 b/(w[j]*Math.pow((1.0-theta[k][j][2])/theta[k][j][2], lambda)));
                }
            }
            resultOfPFDWHM[k][0] = 1.0/(1.0+Math.pow(((n*n+n)/(2*a+2*b))*(1.0/sum[k][0]), 1.0/lambda));
            resultOfPFDWHM[k][1] = 1.0 - 1.0/(1.0+Math.pow(((n*n+n)/(2*a+2*b))*(1.0/sum[k][1]), 1.0/lambda));
            resultOfPFDWHM[k][2] = 1.0 - 1.0/(1.0+Math.pow(((n*n+n)/(2*a+2*b))*(1.0/sum[k][2]), 1.0/lambda));;
        }
        return resultOfPFDWHM;
    }
    
    //Xu et al. 2019 [42] Note: q = 1.0 when calling
    public double[][] PFWMM(int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0; i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);                     
        double[][] result = new double[m][3];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;
            result[k][2] = 1.0;
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                double product2 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][0], q), n*w[curidx]), delta[j]);
                    product1 *= Math.pow((1.0 - Math.pow(theta[k][curidx][1], q*n*w[curidx])), delta[j]);
                    product2 *= Math.pow((1.0 - Math.pow(theta[k][curidx][2], q*n*w[curidx])), delta[j]);
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
                result[k][2] *= (1.0 - product2);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1), 1.0/q);
            result[k][2] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][2], factorial1(n)), sumdelta1), 1.0/q); 
        }        
        return result;       
    }
}